$(function(){

	$("#caixaVolta").hide();
	$("#tipoViagem").change(mostraEscondeVolta);

	$("#btnCalcular").click(calcularPreco);

});

function mostraEscondeVolta() {
	var tipo = $("#tipoViagem").val();
	if ( tipo == "ida" ) {
		$("#caixaVolta").hide();
	} else {
		$("#caixaVolta").show();
	}
}

function calcularPreco() {
	var adultos  = $("#adultos").val();
	var criancas = $("#criancas").val();
	var bebes    = $("#bebes").val();

	var origem   = $("#origem").val();
	var destino  = $("#destino").val();

	if ( bebes > 0 && adultos < 1 ) {
		alert("Um bebê não pode viajar sozinho!");
		return;
	}

	if ( origem == destino ) {
		alert("A origem não pode ser igual ao destino!");
		return;
	}

	
	var passagem = 0;
	if ( (origem == "SP" && destino == "MG") || (origem == "MG" && destino == "SP") ) {
		passagem = 100;
	}

	if ( (origem == "SP" && destino == "PR") || (origem == "PR" && destino == "SP") ) {
		passagem = 120;
	}

	if ( (origem == "PR" && destino == "MG") || (origem == "MG" && destino == "PR") ) {
		passagem = 140;
	}

	var total = 0;
	total = adultos*passagem + (criancas/2)*passagem;

	var tipo = $("#tipoViagem").val();

	if ( tipo == "volta" ) {
		total = total * 2;
	}

	$("#resultado").text("Preço total: R$ " + total);

}