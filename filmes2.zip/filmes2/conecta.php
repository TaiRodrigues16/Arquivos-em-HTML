<?php
// conecta.php
$con = mysql_connect("localhost", "root", "") or die("Erro de Conexão"); //endereço: localhost, root: usuario, "" = senha
mysql_select_db("filmes") or die("BD não encontrado!");
?>