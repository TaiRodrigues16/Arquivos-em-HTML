<?php
// inclui um arquivo externo neste arquivo
include("conecta.php");
?>

<form action="" method="post">
	Buscar filme:
	<input type="text" name="titulofilme" /><br>
	Buscar ator: 
	<input type="text" name="nomeator" /><br>
	<input type="submit" value="Enviar" />
</form>

<?php
if ( isset($_POST['titulofilme']) || isset($_POST['nomeator']) ) {
	
	if ( isset($_POST['titulofilme']) && !empty($_POST['titulofilme']) ) {
		include("buscafilme.php");
	}
	if ( isset($_POST['nomeator']) && !empty($_POST['nomeator']) ) {
		include("buscaator.php");
	}

} else {

	include("listacompleta.php");

}
?>