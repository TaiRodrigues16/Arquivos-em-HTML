<?php
// buscaator.php

$nome = $_POST['nomeator'];

$sql = "SELECT DISTINCT(F.id), F.*
		FROM filmes AS F, atores AS A, atores_filmes AS AF
		WHERE A.id = AF.ator_id AND AF.filme_id = F.id
		AND A.nome LIKE '%$nome%'
		";

$sel = mysql_query( $sql );

$total = mysql_num_rows($sel);

if ( $total > 0 ) {

	echo "Busca: {$nome}<br>";
	echo "Foram encontrado(s) {$total} filme(s):<br>";

	while ( $reg = mysql_fetch_assoc($sel)) {
		echo $reg["titulo"]."<br>";
		$poster = $reg["poster"];
		echo "<img src='{$poster}'><br>";
		echo "<a href=''>Ver detalhes</a><br>";
	}

} else {

	echo "Nenhum filme encontrado para a busca: {$titulo}";

}
?>