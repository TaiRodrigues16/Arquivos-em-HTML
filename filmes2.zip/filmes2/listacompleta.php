<?php
// listacompleta.php

//Executando um comando SQL
$sel = mysql_query("SELECT * FROM filmes");

//Quantidade de registro encontrados
$total = mysql_num_rows($sel);
       
echo "Total de registros: " . $total;
echo "<br>";

//Percorrendo os registros
while ( $reg = mysql_fetch_assoc($sel)) {
	echo $reg["titulo"]."<br>";

	//echo '<img src="' . $reg["poster"] . '"><br>';

	//echo "<img src='" . $reg["poster"] . "'><br>";
	$poster = $reg["poster"];
	echo "<img src='{$poster}'><br>";
	echo "<a href=''>Ver detalhes</a><br>";
}
?>