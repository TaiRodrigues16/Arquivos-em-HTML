//scripts.js 
//Função principal, é chamada quando a página é carregada
$(function(){

	//Seletores -> pegar um elemento html
	// $("#idDoElemento").algumacoisa();
	// $(".classDoElemento").algumacoisa();
	$("#caixa").text("Minha caixa");

	// Ativa como evento "click" e chama a função mudaTexto
	$("#btnMudar").click( mudaTexto );

	//$("#caixa").hide(); //show()

	$("#btnMostrar").click( apareceCaixa );

	$("#btnPegar").click( pegarCaixa );

	$("#btnLeft").click( alinhaLeft );

	$("#btnRight").click( alinhaRight );

	$("#btnCenter").click( alinhaCenter );

	$("#btnJustify").click( justificar );

	ensinaFrutas();

});

function ensinaFrutas(){
	//first(), last(), next(), prev(), nth() -> enésimo
	var primeiro = $("#frutas li").first().text();
	var ultimo = $("#frutas li").last().text();
	
	var inicio = $("#frutas li").first();
	var segundo = inicio.next();
	var quarto = inicio.next().next().next();

	var terceiro = $("#frutas li").eq(3);
	var tamanho = $("#frutas li").length;

	trocaCaixa( terceiro.text() );

	/*
	Faça um FOR que percorra toda a lista, mostrando cada uma das frutas na caixa, uma por linha
	*/
	trocaCaixa('');
	for (var i = 0; i < tamanho; i++) {
		var el = $("#frutas li").eq(i);
		$("#caixa").append( el.text() + "<br>" );
	};
}

function trocaCaixa(txt) {
	$("#caixa").text( txt );
}

function alinhaLeft(){
	// Alterando o atributo de TODO parágrafo
	// attr("propriedade", "valor")
	$("p").attr("align", "left");
}

function alinhaRight(){
	// Alterando o atributo de TODO parágrafo
	// attr("propriedade", "valor")
	$("p").attr("align", "right");
}

function alinhaCenter(){
	// Alterando o atributo de TODO parágrafo
	// attr("propriedade", "valor")
	$("p").attr("align", "center");
}

function justificar(){
	// Alterando o atributo de TODO parágrafo
	// attr("propriedade", "valor")
	$("p").attr("align", "justify");
}

// function nomeDaFuncao (param1, param2, param3)
function mudaTexto() {
	$("#caixa").html("Mudou o texto da <b>caixa</b>");
	$("#caixa").append("<br>Mais texto");
}

function apareceCaixa(){
	//$("#caixa").show(1000);
	$("#caixa").toggle(500); // Mostra e esconde quando clica.
}

function pegarCaixa(){
	var texto;
	texto = $("#caixa").text();
	alert(texto);
}