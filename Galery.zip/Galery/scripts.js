$(function(){

    $("#slider img").click(clicafoto); 

    $("#btnleft").click(esquerda);

    $("#btnright").click(direita);


});

var atual = 1;

function clicafoto(){
    var endereco = $(this).attr("src");
    endereco = endereco.replace("Pequena", "Grande");
   // $("#grande").text(endereco);
    $("#grande img").attr("src",endereco);
    atual = $(this).attr("id");

    if(atual==1){
        var leg = $(this).attr("alt");
        $("#grande figcaption").text(leg);
    }

    if(atual==2){
        var leg = $(this).attr("alt");
        $("#grande figcaption").text(leg); 
    }

    if(atual==3){
        var leg = $(this).attr("alt");
        $("#grande figcaption").text(leg);
    }

    if(atual==4){
        var leg = $(this).attr("alt");
        $("#grande figcaption").text(leg);
    }
    if(atual==5){
        var leg = $(this).attr("alt");
        $("#grande figcaption").text(leg);
    }

    if(atual==6){
        var leg = $(this).attr("alt");
        $("#grande figcaption").text(leg);
    }

    if(atual==7){
        var leg = $(this).attr("alt");
        $("#grande figcaption").text(leg); 
    }
}

function esquerda(){
    atual = atual - 1;

    if(atual == 0){
        atual = 7;
    }

    var endereco = "ImageGrande/img"+atual+".jpg";
    $("#grande img").attr("src",endereco);
    var leg = $(this).attr("class");
    $("#grande figcaption").text(leg);
   
}

function direita(){
    
    atual = atual + 1;

    if(atual == 8){
        atual = 1;
    }

    var endereco = "ImageGrande/img"+atual+".jpg";
    $("#grande img").attr("src",endereco);
    var leg = $(this).attr("class");
    $("#grande figcaption").text(leg);
}